# TP 3 – Questions (a) to (e)

## (a) What does `left to right direction` change? What does the arrow of `Customer --> Withdraw` mean, and which notation does Chapter 3 use?

`left to right direction` changes the layout orientation of the diagram: elements are arranged from left to right instead of from top to bottom. It changes the presentation, not the meaning of the use cases.

In PlantUML, `Customer --> Withdraw` draws a directed line with an arrowhead from the actor to the use case. It indicates the direction used to draw the association; it does not represent the order of actions or a flow of control. For the actor–use-case association, Chapter 3 uses a simple undirected association line (`--`), without an arrowhead.

## (b) Did the tool detect the reversed `extend` relationship from Part B? What does a modeling tool check, and what does it not check?

No. PlantUML can render the relationship even when its direction is reversed. It checks the diagram's syntax sufficiently to generate the drawing, but it does not necessarily detect whether the model expresses the correct UML meaning. The modeler must check semantic rules, such as the direction of `<<extend>>`, and verify that the diagram matches the requirements.

## (c) Give two advantages and two drawbacks of the automatic layout of PlantUML.

**Advantages:**
1. It is fast and saves time because the tool arranges the elements automatically.
2. The layout is reproducible and easy to update when the source text changes.

**Drawbacks:**
1. The modeler has limited control over the exact position and spacing of elements.
2. For complex diagrams, the automatic layout may create crossings or a less clear arrangement, so manual adjustments may be needed.

## (d) Compare a text-based tool such as PlantUML with a graphical tool such as Modelio: editing, layout, version control, consistency between diagrams.

PlantUML diagrams are written as text, so they are quick to edit, easy to review, and work well with Git. Their layout is mostly automatic, which makes it consistent but gives less direct control over element positions. Modelio provides a graphical editor: the user creates and moves diagram elements visually and has more control over the layout. However, graphical project files can be less convenient to compare line by line in Git. Both tools can help maintain consistency, but the modeler must still ensure that related diagrams use the same names and represent the same system rules.

## (e) Why is it useful to keep the models in the same repository as the code?

Keeping the UML models in the same repository as the source code makes it easier to version and review them together. The Git history shows how the design and implementation change over time. It also helps developers find the diagrams, compare changes, and keep the documentation consistent with the code.


## Part E – Git diff: text model and PNG export

When a `.puml` text file is changed, `git diff` can display the exact added, removed, and modified lines. A PNG file is binary, so the normal `git diff` does not show the visual changes as readable text; it usually only reports that the binary file changed. The PNG can be opened separately to compare the diagrams visually.
