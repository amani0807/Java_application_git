# UC-07 – Register a Return

## 1. Use Case Name
Register a Return

## 2. Use Case ID
UC-07

## 3. Primary Actor
Librarian

## 4. Secondary Actors
Mail server

## 5. Goal
To register the return of a borrowed book copy.

## 6. Trigger
A member brings a book copy to the library to return it.

## 7. Preconditions
- The librarian is logged into the library system.
- The returned copy is identified by its barcode or inventory number.

## 8. Postconditions
- If the copy is on loan, the loan is closed and the copy status is updated.
- If the copy is reserved, it is kept aside and the member who reserved it is notified by the mail server.
- If the return is late, the extension point `late return` may execute the use case **Suspend the member**.
- A return receipt is printed after a successful return.

## 9. Main Success Scenario
1. The member brings back the borrowed copy.
2. The librarian receives the copy.
3. The librarian scans the copy's barcode to identify it.
4. The system checks whether the copy is currently on loan.
5. The system checks the loan information.
6. The system closes the loan.
7. The system updates the copy status.
8. The system checks whether the copy is reserved.
9. If the copy is reserved, the system keeps it aside and asks the mail server to notify the member who reserved it; otherwise, the copy is made available.
10. If the return is late, the `late return` extension point is activated and **Suspend the member** is executed.
11. The librarian completes the return process.
12. The system prints the receipt.

## 10. Extensions / Alternative Flows

**1a. Barcode cannot be read**
- The librarian enters the copy's inventory number manually.
- The system uses the inventory number to identify the copy, then continues at step 4.

**2a. The copy is not currently on loan**
- The system displays an error message indicating that the copy is not registered as borrowed.
- The use case ends without closing a loan or printing a successful return receipt.

**Late return (extension point: `late return`)**
- The system detects that the return is late.
- The system executes **Suspend the member**.

**Reserved copy**
- The system detects an existing reservation.
- The copy is kept aside.
- The mail server sends a notification to the member who reserved it.

## 11. Special Requirements
- The system must correctly identify the returned copy and update the loan status.
- The system must notify the member when a reserved copy is available.
- The system must print a receipt after a successful return.

## 12. Frequency of Use
This use case occurs whenever a member returns a borrowed book copy.
