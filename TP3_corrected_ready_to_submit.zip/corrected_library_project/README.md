# TP 3 – Use Case Diagrams with a UML Tool

This folder contains the corrected PlantUML sources, PNG diagram exports, the fully dressed UC-07 description, and answers to questions (a)–(e).

## Contents
- `docs/uml/use-cases.puml` and `.png`
- `docs/uml/register-loan-activity.puml` and `.png`
- `docs/uml/register-return.md`
- `docs/uml/register-return-activity.puml` and `.png`
- `docs/uml/atm.puml` and `.png` (additional supplied example)
- `docs/uml/answers-tp3.md`

## Important notes
- The use-case relationship is corrected to `Suspend the member ..> Register a return : <<extend>>`.
- UC-07 has only the Mail server as secondary actor; the Trigger and alternative flows 1a and 2a are included.
- The activity diagrams include the requested receipt step.
- PNGs are visual exports included with the source files. If the instructor requires PlantUML-generated PNGs specifically, regenerate them from the `.puml` sources using PlantUML before submission.

## Git steps in the original TP2 repository
Copy the `docs/uml` folder into the original TP2 repository, then run:

```bash
git status
git add docs/uml
git commit -m "Add corrected TP3 UML models and answers"
```

For the Part E comparison: `git diff` shows line-by-line edits for `.puml` text files, while PNG files are binary and normally appear only as changed binary files.

The original Git repository was not included with the uploaded files, so no Git commit or repository history has been created in this package.
